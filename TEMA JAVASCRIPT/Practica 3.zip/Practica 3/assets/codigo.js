const b = document.querySelector("body");
const ejercicio1 = document.querySelector("#ejercicio1");
const ejercicio2 = document.querySelector("#ejercicio2");
const ejercicio3 = document.querySelector("#ejercicio3");
const ejercicio4 = document.querySelector("#ejercicio4");
const ejercicio5 = document.querySelector("#ejercicio5");
const ejercicio6 = document.querySelector("#ejercicio6");

b.addEventListener("load", mensaje());

function mensaje(){
    alert("Bienvenidos a la prácticas de eventos");
}

ejercicio1.addEventListener("click", () => alert("Has realizado un click"));

ejercicio2.addEventListener("click", calculaNumero);

function calculaNumero(){
    const numero1 = parseInt(prompt("Introduce un numero:"));
    const numero2 = parseInt(prompt("Introduce un numero:"));

    if (isNaN(numero1) || isNaN(numero2)){
        alert("Introduce un numero correcto por favor");
    } else {
        const numeroMayor = numero1 > numero2 ? numero1 : numero2;
        alert(`El número mayor es: ${numeroMayor}`);
    } 
}

ejercicio3.addEventListener("mouseleave", parImpar);

function parImpar(){
    const numero = parseInt(prompt("Introduce un numero:"));

    if (isNaN(numero)) {
        alert("Introduce un numero correcto por favor");
    } else if (numero % 2 == 0){
        alert(`${numero} es par`);
    } else {
        alert(`${numero} es impar`);
    }
}

ejercicio4.addEventListener("dblclick", () => alert("Has realizado doble click"));

ejercicio5.addEventListener("click", contarClick);
let contador = 0;
function contarClick(){
    contador++;
    alert(`Has realizado ${contador} clicks`);
}

ejercicio6.addEventListener("mouseenter", multiplicaNumeros);

function multiplicaNumeros(){
    const numero1 = parseInt(prompt("Introduce un numero:"));
    const numero2 = parseInt(prompt("Introduce otro numero:"));

    const multiplicacion = numero1 * numero2;

    alert(`La multiplicacion de ${numero1} y ${numero2} es ${multiplicacion}`);
}